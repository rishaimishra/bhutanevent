@extends('layouts.app')

@section('title', 'About - Bhutan Echos')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">About Us</div>
                <div class="card-body">
                    <h1>About Bhutan Echos</h1>
                    <p>Learn more about our company and our mission.</p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection 