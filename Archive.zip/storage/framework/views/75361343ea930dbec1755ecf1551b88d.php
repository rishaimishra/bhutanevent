<?php $__env->startSection('title', 'Home - Bhutan Echos'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Welcome to Bhutan Echos</div>
                <div class="card-body">
                    <h1>Welcome to Our Website</h1>
                    <p>This is the homepage of Bhutan Echos. Here you can find information about our services and more.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/Myssd/php_projects/bhutan-echos/resources/views/pages/home.blade.php ENDPATH**/ ?>