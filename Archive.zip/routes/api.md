1. get api for question
2. get poll and submit response
3. get notification api
4. login and signup api and get profile api and update profile api - 1
5. timeline api - 2
6. get royal audio api
7. get ebook api
8. get question list with options and users score api
9. submit feebback api for session